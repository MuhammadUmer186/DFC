import 'package:flutter/foundation.dart';
import '../models/food_item.dart';

class CartProvider extends ChangeNotifier {
  final List<CartLine> _lines = [];
  String? promoCode;
  int discount = 0;
  static const int deliveryFee = 100;

  List<CartLine> get lines => List.unmodifiable(_lines);
  int get itemCount => _lines.fold(0, (s, l) => s + l.quantity);
  int get subtotal => _lines.fold(0, (s, l) => s + l.total);
  int get total {
    final t = subtotal + (subtotal > 0 ? deliveryFee : 0) - discount;
    return t < 0 ? 0 : t;
  }

  void add(FoodItem item, {SizeOption? size, List<AddOn> addOns = const [], int qty = 1}) {
    final sizeLabel = size?.label;
    final addOnKey = addOns.map((a) => a.name).join(',');
    final existing = _lines.where((l) =>
        l.item.id == item.id &&
        l.size?.label == sizeLabel &&
        l.addOns.map((a) => a.name).join(',') == addOnKey);
    if (existing.isNotEmpty) {
      existing.first.quantity += qty;
    } else {
      _lines.add(CartLine(item: item, size: size, addOns: addOns, quantity: qty));
    }
    notifyListeners();
  }

  void changeQty(CartLine line, int delta) {
    line.quantity += delta;
    if (line.quantity <= 0) _lines.remove(line);
    notifyListeners();
  }

  void remove(CartLine line) {
    _lines.remove(line);
    notifyListeners();
  }

  void applyPromo(String code) {
    promoCode = code;
    // Demo promo: DFC100 => Rs 100 off.
    discount = code.trim().toUpperCase() == 'DFC100' ? 100 : 0;
    notifyListeners();
  }

  void clear() {
    _lines.clear();
    promoCode = null;
    discount = 0;
    notifyListeners();
  }
}
