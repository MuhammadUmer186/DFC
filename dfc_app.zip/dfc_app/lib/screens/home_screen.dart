import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import '../data/menu_data.dart';
import '../models/food_item.dart';
import '../providers/cart_provider.dart';
import '../theme/app_theme.dart';
import '../widgets/cart_icon.dart';
import '../widgets/dfc_logo.dart';
import 'product_detail_screen.dart';

class HomeScreen extends StatelessWidget {
  final VoidCallback onSeeMenu;
  const HomeScreen({super.key, required this.onSeeMenu});

  String get _greeting {
    final h = DateTime.now().hour;
    if (h < 12) return 'Good morning!';
    if (h < 17) return 'Good afternoon!';
    return 'Good evening!';
  }

  @override
  Widget build(BuildContext context) {
    final popular = [itemById('zinger-burger'), itemById('loaded-fries'), itemById('chicken-shawarma')];
    return Scaffold(
      backgroundColor: AppColors.bg,
      body: Column(
        children: [
          // ── Dark header ──
          Container(
            color: AppColors.navy,
            padding: const EdgeInsets.fromLTRB(18, 0, 18, 16),
            child: SafeArea(
              bottom: false,
              child: Column(
                children: [
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      const DfcLogo(size: 46),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(_greeting,
                                style: const TextStyle(
                                    color: Colors.white70, fontSize: 13)),
                            Row(
                              children: const [
                                Icon(Icons.location_on,
                                    color: AppColors.yellow, size: 16),
                                SizedBox(width: 4),
                                Text('Wah Cantt',
                                    style: TextStyle(
                                        color: Colors.white,
                                        fontSize: 16,
                                        fontWeight: FontWeight.w700)),
                                Icon(Icons.keyboard_arrow_down,
                                    color: Colors.white, size: 20),
                              ],
                            ),
                          ],
                        ),
                      ),
                      const CartIcon(),
                    ],
                  ),
                  const SizedBox(height: 16),
                  // Search
                  GestureDetector(
                    onTap: onSeeMenu,
                    child: Container(
                      height: 48,
                      padding: const EdgeInsets.symmetric(horizontal: 14),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(14),
                      ),
                      child: Row(children: const [
                        Icon(Icons.search, color: AppColors.textGrey),
                        SizedBox(width: 8),
                        Text('Search burgers, fries & more',
                            style: TextStyle(
                                color: AppColors.textGrey, fontSize: 15)),
                      ]),
                    ),
                  ),
                ],
              ),
            ),
          ),
          // ── Body ──
          Expanded(
            child: ListView(
              padding: const EdgeInsets.fromLTRB(18, 16, 18, 16),
              children: [
                _DealBanner(onTap: onSeeMenu),
                const SizedBox(height: 16),
                // Categories
                SizedBox(
                  height: 78,
                  child: ListView.separated(
                    scrollDirection: Axis.horizontal,
                    itemCount: kCategories.length,
                    separatorBuilder: (_, __) => const SizedBox(width: 12),
                    itemBuilder: (_, i) => _CategoryChip(
                      emoji: kCategories[i].$2,
                      label: kCategories[i].$1,
                      onTap: onSeeMenu,
                    ),
                  ),
                ),
                const SizedBox(height: 18),
                Row(
                  children: [
                    Text('Popular near you',
                        style: GoogleFonts.inter(
                            fontSize: 18, fontWeight: FontWeight.w800)),
                    const Spacer(),
                    GestureDetector(
                      onTap: onSeeMenu,
                      child: const Text('View all',
                          style: TextStyle(
                              color: AppColors.orange,
                              fontWeight: FontWeight.w600)),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                SizedBox(
                  height: 210,
                  child: ListView.separated(
                    scrollDirection: Axis.horizontal,
                    itemCount: popular.length,
                    separatorBuilder: (_, __) => const SizedBox(width: 14),
                    itemBuilder: (_, i) => _PopularCard(item: popular[i]),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _DealBanner extends StatelessWidget {
  final VoidCallback onTap;
  const _DealBanner({required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 170,
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          color: AppColors.navy,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: AppColors.yellow.withOpacity(0.6)),
        ),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text('Crunch\nDeal',
                      style: GoogleFonts.inter(
                          color: Colors.white,
                          height: 1.1,
                          fontSize: 26,
                          fontWeight: FontWeight.w800)),
                  const SizedBox(height: 6),
                  const Text('2 Zinger Burgers\n+ 2 Fries + 2 Drinks',
                      style: TextStyle(color: Colors.white70, fontSize: 12.5)),
                  const SizedBox(height: 6),
                  Text('Rs 899',
                      style: GoogleFonts.inter(
                          color: AppColors.yellow,
                          fontSize: 26,
                          fontWeight: FontWeight.w800)),
                ],
              ),
            ),
            const Text('🍔🍟\n🥤', textAlign: TextAlign.center, style: TextStyle(fontSize: 40)),
          ],
        ),
      ),
    );
  }
}

class _CategoryChip extends StatelessWidget {
  final String emoji, label;
  final VoidCallback onTap;
  const _CategoryChip({required this.emoji, required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 66,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: AppColors.border),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(emoji, style: const TextStyle(fontSize: 24)),
            const SizedBox(height: 4),
            Text(label,
                style: const TextStyle(
                    fontSize: 11.5, fontWeight: FontWeight.w600)),
          ],
        ),
      ),
    );
  }
}

class _PopularCard extends StatelessWidget {
  final FoodItem item;
  const _PopularCard({required this.item});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => ProductDetailScreen(item: item))),
      child: Container(
        width: 150,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
                color: Colors.black.withOpacity(0.05),
                blurRadius: 10,
                offset: const Offset(0, 4)),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            FoodImage(
              asset: item.asset,
              emoji: item.emoji,
              width: 150,
              height: 110,
              radius: const BorderRadius.vertical(top: Radius.circular(16)),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(10, 8, 10, 10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(item.name,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                          fontWeight: FontWeight.w700, fontSize: 13.5)),
                  const SizedBox(height: 3),
                  Row(children: [
                    const Icon(Icons.star, size: 14, color: AppColors.star),
                    const SizedBox(width: 3),
                    Text('${item.rating}',
                        style: const TextStyle(
                            fontSize: 12, color: AppColors.textGrey)),
                  ]),
                  const SizedBox(height: 5),
                  Row(
                    children: [
                      Text('Rs ${item.price}',
                          style: const TextStyle(
                              fontWeight: FontWeight.w800, fontSize: 14)),
                      const Spacer(),
                      _AddButton(item: item),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _AddButton extends StatelessWidget {
  final FoodItem item;
  const _AddButton({required this.item});
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        context.read<CartProvider>().add(item,
            size: item.sizes.isNotEmpty ? item.sizes.first : null);
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('${item.name} added to cart'),
          duration: const Duration(milliseconds: 900),
        ));
      },
      child: Container(
        width: 28,
        height: 28,
        decoration: const BoxDecoration(
            color: AppColors.yellow, shape: BoxShape.circle),
        child: const Icon(Icons.add, size: 18, color: AppColors.textDark),
      ),
    );
  }
}
