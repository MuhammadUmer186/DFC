import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../services/auth_service.dart';
import '../theme/app_theme.dart';
import '../widgets/dfc_logo.dart';
import 'login_screen.dart';
import 'orders_screen.dart';
import 'track_order_screen.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final user = (() {
      try {
        return AuthService.instance.currentUser;
      } catch (_) {
        return null;
      }
    })();
    final name = user?.displayName ?? 'Guest';
    final photo = user?.photoURL;

    return Scaffold(
      backgroundColor: AppColors.bg,
      body: Column(
        children: [
          // ── Dark header ──
          Container(
            color: AppColors.navy,
            padding: const EdgeInsets.fromLTRB(18, 0, 18, 18),
            child: SafeArea(
              bottom: false,
              child: Row(children: [
                const DfcLogo(size: 44),
                const SizedBox(width: 12),
                Text('My DFC',
                    style: GoogleFonts.inter(
                        color: Colors.white,
                        fontSize: 20,
                        fontWeight: FontWeight.w800)),
                const Spacer(),
                Stack(clipBehavior: Clip.none, children: [
                  const Icon(Icons.notifications_none,
                      color: Colors.white, size: 28),
                  Positioned(
                    right: -4, top: -4,
                    child: CircleAvatar(
                      radius: 9,
                      backgroundColor: AppColors.yellow,
                      child: const Text('2',
                          style: TextStyle(
                              fontSize: 10,
                              fontWeight: FontWeight.w800,
                              color: AppColors.textDark)),
                    ),
                  ),
                ]),
              ]),
            ),
          ),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.fromLTRB(18, 16, 18, 16),
              children: [
                // User card
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: AppColors.border),
                  ),
                  child: Row(children: [
                    CircleAvatar(
                      radius: 26,
                      backgroundColor: const Color(0xFFEFE6D2),
                      backgroundImage:
                          photo != null ? NetworkImage(photo) : null,
                      child: photo == null
                          ? const Icon(Icons.person,
                              size: 28, color: AppColors.textGrey)
                          : null,
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Text(name,
                          style: GoogleFonts.inter(
                              fontSize: 18, fontWeight: FontWeight.w800)),
                    ),
                    const Icon(Icons.chevron_right,
                        color: AppColors.textGrey),
                  ]),
                ),
                const SizedBox(height: 14),
                // Rewards card
                Container(
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(
                    color: AppColors.navy,
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Row(children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('DFC Rewards',
                              style: GoogleFonts.inter(
                                  color: Colors.white,
                                  fontSize: 16,
                                  fontWeight: FontWeight.w700)),
                          const SizedBox(height: 4),
                          RichText(
                            text: TextSpan(
                              children: [
                                TextSpan(
                                    text: '320 ',
                                    style: GoogleFonts.inter(
                                        color: AppColors.yellow,
                                        fontSize: 28,
                                        fontWeight: FontWeight.w800)),
                                const TextSpan(
                                    text: 'points',
                                    style: TextStyle(
                                        color: Colors.white70,
                                        fontSize: 15)),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      width: 52, height: 52,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border:
                            Border.all(color: AppColors.yellow, width: 2),
                      ),
                      child: const Icon(Icons.star,
                          color: AppColors.yellow, size: 28),
                    ),
                  ]),
                ),
                const SizedBox(height: 18),
                Row(children: [
                  Text('Recent Orders',
                      style: GoogleFonts.inter(
                          fontSize: 17, fontWeight: FontWeight.w800)),
                  const Spacer(),
                  const Text('View all',
                      style: TextStyle(
                          color: AppColors.orange,
                          fontWeight: FontWeight.w600)),
                ]),
                const SizedBox(height: 12),
                OrderTile(
                  id: '#DFC-1048',
                  status: 'On the way',
                  statusColor: AppColors.orange,
                  items: 'Loaded Fries, Zinger Burger',
                  price: 'Rs 1,000',
                  emoji: '🍟',
                  trailing: TextButton(
                    onPressed: () => Navigator.of(context).push(
                        MaterialPageRoute(
                            builder: (_) => const TrackOrderScreen())),
                    child: const Text('Track',
                        style: TextStyle(
                            color: AppColors.orange,
                            fontWeight: FontWeight.w700)),
                  ),
                ),
                OrderTile(
                  id: '#DFC-1021',
                  status: 'Delivered',
                  statusColor: AppColors.green,
                  items: 'Chicken Shawarma, Fries',
                  price: 'Rs 750',
                  emoji: '🌯',
                  trailing: OutlinedButton(
                    onPressed: () {},
                    style: OutlinedButton.styleFrom(
                      side: const BorderSide(color: AppColors.yellow),
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10)),
                    ),
                    child: const Text('Reorder',
                        style: TextStyle(
                            color: AppColors.yellowDark,
                            fontWeight: FontWeight.w700)),
                  ),
                ),
                const SizedBox(height: 8),
                _MenuRow(icon: Icons.location_on_outlined, label: 'Saved Addresses'),
                _MenuRow(icon: Icons.credit_card_outlined, label: 'Payment Methods'),
                _MenuRow(icon: Icons.help_outline, label: 'Help & Support'),
                const SizedBox(height: 8),
                _MenuRow(
                  icon: Icons.logout,
                  label: user == null ? 'Sign In' : 'Sign Out',
                  color: AppColors.red,
                  onTap: () async {
                    try {
                      await AuthService.instance.signOut();
                    } catch (_) {}
                    if (context.mounted) {
                      Navigator.of(context).pushAndRemoveUntil(
                          MaterialPageRoute(
                              builder: (_) => const LoginScreen()),
                          (_) => false);
                    }
                  },
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _MenuRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color? color;
  final VoidCallback? onTap;
  const _MenuRow(
      {required this.icon, required this.label, this.color, this.onTap});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.border),
      ),
      child: ListTile(
        onTap: onTap ?? () {},
        leading: CircleAvatar(
          radius: 18,
          backgroundColor: const Color(0xFFF4F4F2),
          child: Icon(icon, size: 20, color: color ?? AppColors.textDark),
        ),
        title: Text(label,
            style: TextStyle(
                fontWeight: FontWeight.w700,
                fontSize: 15,
                color: color ?? AppColors.textDark)),
        trailing:
            const Icon(Icons.chevron_right, color: AppColors.textGrey),
      ),
    );
  }
}
