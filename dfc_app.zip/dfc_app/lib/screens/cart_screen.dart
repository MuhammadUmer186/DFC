import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import '../data/menu_data.dart';
import '../models/food_item.dart';
import '../providers/cart_provider.dart';
import '../theme/app_theme.dart';
import '../widgets/dfc_logo.dart';
import 'checkout_screen.dart';

class CartScreen extends StatefulWidget {
  const CartScreen({super.key});
  @override
  State<CartScreen> createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {
  final _promoCtrl = TextEditingController();

  @override
  void dispose() {
    _promoCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final cart = context.watch<CartProvider>();
    final cheeseDip = itemById('classic-fries').addOns.first;
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        leading: IconButton(
            icon: const Icon(Icons.arrow_back),
            onPressed: () => Navigator.pop(context)),
        title: Text('Your Cart',
            style: GoogleFonts.inter(fontSize: 19, fontWeight: FontWeight.w800)),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 16),
            child: Stack(clipBehavior: Clip.none, children: [
              const Icon(Icons.shopping_cart_outlined, size: 26),
              if (cart.itemCount > 0)
                Positioned(
                  right: -6, top: -6,
                  child: CircleAvatar(
                    radius: 9,
                    backgroundColor: AppColors.yellow,
                    child: Text('${cart.itemCount}',
                        style: const TextStyle(
                            fontSize: 10,
                            fontWeight: FontWeight.w800,
                            color: AppColors.textDark)),
                  ),
                ),
            ]),
          ),
        ],
      ),
      body: cart.lines.isEmpty
          ? const Center(
              child: Text('Your cart is empty 🛒',
                  style: TextStyle(fontSize: 17, color: AppColors.textGrey)))
          : Column(
              children: [
                Expanded(
                  child: ListView(
                    padding: const EdgeInsets.fromLTRB(18, 4, 18, 12),
                    children: [
                      Row(children: const [
                        Icon(Icons.location_on,
                            color: AppColors.yellowDark, size: 18),
                        SizedBox(width: 6),
                        Text('Wah Cantt',
                            style: TextStyle(
                                fontWeight: FontWeight.w700, fontSize: 15)),
                        Icon(Icons.keyboard_arrow_down, size: 20),
                      ]),
                      const SizedBox(height: 12),
                      ...cart.lines.map((l) => _CartRow(line: l)),
                      const SizedBox(height: 12),
                      Text('Add something extra',
                          style: GoogleFonts.inter(
                              fontSize: 16, fontWeight: FontWeight.w800)),
                      const SizedBox(height: 10),
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(color: AppColors.border),
                        ),
                        child: Row(children: [
                          const CircleAvatar(
                              radius: 22,
                              backgroundColor: Color(0xFFFFF3D6),
                              child: Text('🧀', style: TextStyle(fontSize: 20))),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(cheeseDip.name,
                                    style: const TextStyle(
                                        fontWeight: FontWeight.w700)),
                                Text('Rs ${cheeseDip.price}',
                                    style: const TextStyle(
                                        color: AppColors.textGrey,
                                        fontSize: 13)),
                              ],
                            ),
                          ),
                          GestureDetector(
                            onTap: () {
                              final fries = itemById('classic-fries');
                              context.read<CartProvider>().add(fries,
                                  size: fries.sizes.first,
                                  addOns: [cheeseDip]);
                            },
                            child: Container(
                              width: 30, height: 30,
                              decoration: const BoxDecoration(
                                  color: AppColors.yellow,
                                  shape: BoxShape.circle),
                              child: const Icon(Icons.add,
                                  size: 19, color: AppColors.textDark),
                            ),
                          ),
                        ]),
                      ),
                      const SizedBox(height: 16),
                      // Promo
                      Row(children: [
                        Expanded(
                          child: TextField(
                            controller: _promoCtrl,
                            decoration: const InputDecoration(
                              hintText: 'Enter promo code',
                              prefixIcon: Icon(Icons.local_offer_outlined,
                                  size: 20, color: AppColors.textGrey),
                            ),
                          ),
                        ),
                        const SizedBox(width: 10),
                        SizedBox(
                          height: 52,
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                                minimumSize: const Size(90, 52)),
                            onPressed: () {
                              cart.applyPromo(_promoCtrl.text);
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                    content: Text(cart.discount > 0
                                        ? 'Promo applied! Rs ${cart.discount} off'
                                        : 'Invalid promo code (try DFC100)')),
                              );
                            },
                            child: const Text('Apply'),
                          ),
                        ),
                      ]),
                      const SizedBox(height: 16),
                      _priceRow('Subtotal', 'Rs ${cart.subtotal}'),
                      _priceRow('Delivery', 'Rs ${CartProvider.deliveryFee}'),
                      if (cart.discount > 0)
                        _priceRow('Discount', '-Rs ${cart.discount}',
                            color: AppColors.green),
                      const Divider(height: 24),
                      Row(children: [
                        Text('Total',
                            style: GoogleFonts.inter(
                                fontSize: 18, fontWeight: FontWeight.w800)),
                        const Spacer(),
                        Text('Rs ${cart.total}',
                            style: GoogleFonts.inter(
                                fontSize: 18, fontWeight: FontWeight.w800)),
                      ]),
                    ],
                  ),
                ),
                SafeArea(
                  top: false,
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(18, 6, 18, 12),
                    child: ElevatedButton(
                      onPressed: () => Navigator.of(context).push(
                          MaterialPageRoute(
                              builder: (_) => const CheckoutScreen())),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: const [
                          Icon(Icons.shopping_cart, size: 20),
                          SizedBox(width: 10),
                          Text('Proceed to Checkout'),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
    );
  }

  Widget _priceRow(String label, String value, {Color? color}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(children: [
        Text(label,
            style: TextStyle(
                color: color ?? AppColors.textGrey,
                fontSize: 15,
                fontWeight: FontWeight.w500)),
        const Spacer(),
        Text(value,
            style: TextStyle(
                color: color ?? AppColors.textDark,
                fontSize: 15,
                fontWeight: FontWeight.w700)),
      ]),
    );
  }
}

class _CartRow extends StatelessWidget {
  final CartLine line;
  const _CartRow({required this.line});

  @override
  Widget build(BuildContext context) {
    final cart = context.read<CartProvider>();
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Row(
        children: [
          FoodImage(
              asset: line.item.asset,
              emoji: line.item.emoji,
              width: 64, height: 64),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(line.item.name,
                    style: const TextStyle(
                        fontWeight: FontWeight.w700, fontSize: 15.5)),
                if (line.size != null || line.addOns.isNotEmpty)
                  Text(
                    [
                      if (line.size != null) line.size!.label,
                      ...line.addOns.map((a) => a.name),
                    ].join(' • '),
                    style: const TextStyle(
                        fontSize: 12, color: AppColors.textGrey),
                  ),
                const SizedBox(height: 6),
                Row(children: [
                  _stepBtn(Icons.remove, () => cart.changeQty(line, -1)),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 14),
                    child: Text('${line.quantity}',
                        style: const TextStyle(
                            fontWeight: FontWeight.w800, fontSize: 15)),
                  ),
                  _stepBtn(Icons.add, () => cart.changeQty(line, 1),
                      primary: true),
                ]),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text('Rs ${line.total}',
                  style: const TextStyle(
                      fontWeight: FontWeight.w800, fontSize: 15.5)),
              const SizedBox(height: 10),
              GestureDetector(
                onTap: () => cart.remove(line),
                child: const Icon(Icons.delete_outline,
                    color: AppColors.red, size: 22),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _stepBtn(IconData i, VoidCallback onTap, {bool primary = false}) =>
      GestureDetector(
        onTap: onTap,
        child: Container(
          width: 28, height: 28,
          decoration: BoxDecoration(
            color: primary ? AppColors.yellow : Colors.white,
            borderRadius: BorderRadius.circular(8),
            border:
                primary ? null : Border.all(color: AppColors.border),
          ),
          child: Icon(i, size: 16, color: AppColors.textDark),
        ),
      );
}
