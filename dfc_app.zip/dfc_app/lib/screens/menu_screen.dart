import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import '../data/menu_data.dart';
import '../models/food_item.dart';
import '../providers/cart_provider.dart';
import '../theme/app_theme.dart';
import '../widgets/cart_icon.dart';
import '../widgets/dfc_logo.dart';
import 'product_detail_screen.dart';

class MenuScreen extends StatefulWidget {
  const MenuScreen({super.key});
  @override
  State<MenuScreen> createState() => _MenuScreenState();
}

class _MenuScreenState extends State<MenuScreen> {
  String _selected = 'Fries';
  String _query = '';
  final Set<String> _favs = {};

  @override
  Widget build(BuildContext context) {
    final items = kMenu.where((e) {
      final matchCat = _selected == 'Deals' || e.category == _selected;
      final matchQ =
          _query.isEmpty || e.name.toLowerCase().contains(_query.toLowerCase());
      return matchCat && matchQ;
    }).toList();

    return Scaffold(
      backgroundColor: AppColors.bg,
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(18, 10, 18, 0),
              child: Row(
                children: [
                  const SizedBox(width: 28),
                  Expanded(
                    child: Text('Explore Menu',
                        textAlign: TextAlign.center,
                        style: GoogleFonts.inter(
                            fontSize: 20, fontWeight: FontWeight.w800)),
                  ),
                  const CartIcon(color: AppColors.textDark),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(18, 14, 18, 12),
              child: TextField(
                onChanged: (v) => setState(() => _query = v),
                decoration: const InputDecoration(
                  hintText: 'Search menu items...',
                  prefixIcon: Icon(Icons.search, color: AppColors.textGrey),
                ),
              ),
            ),
            // Category chips
            SizedBox(
              height: 78,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 18),
                itemCount: kCategories.length,
                separatorBuilder: (_, __) => const SizedBox(width: 12),
                itemBuilder: (_, i) {
                  final (label, emoji) = kCategories[i];
                  final sel = label == _selected;
                  return GestureDetector(
                    onTap: () => setState(() => _selected = label),
                    child: Container(
                      width: 66,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(
                            color: sel ? AppColors.yellow : AppColors.border,
                            width: sel ? 2 : 1),
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(emoji, style: const TextStyle(fontSize: 24)),
                          const SizedBox(height: 4),
                          Text(label,
                              style: TextStyle(
                                  fontSize: 11.5,
                                  fontWeight: sel
                                      ? FontWeight.w800
                                      : FontWeight.w600)),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
            const SizedBox(height: 8),
            Expanded(
              child: GridView.builder(
                padding: const EdgeInsets.fromLTRB(18, 8, 18, 16),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  mainAxisSpacing: 14,
                  crossAxisSpacing: 14,
                  childAspectRatio: 0.78,
                ),
                itemCount: items.length,
                itemBuilder: (_, i) => _MenuCard(
                  item: items[i],
                  isFav: _favs.contains(items[i].id),
                  onFav: () => setState(() {
                    _favs.contains(items[i].id)
                        ? _favs.remove(items[i].id)
                        : _favs.add(items[i].id);
                  }),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _MenuCard extends StatelessWidget {
  final FoodItem item;
  final bool isFav;
  final VoidCallback onFav;
  const _MenuCard({required this.item, required this.isFav, required this.onFav});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => ProductDetailScreen(item: item))),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
                color: Colors.black.withOpacity(0.05),
                blurRadius: 10,
                offset: const Offset(0, 4)),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Stack(
              children: [
                FoodImage(
                  asset: item.asset,
                  emoji: item.emoji,
                  width: double.infinity,
                  height: 120,
                  radius:
                      const BorderRadius.vertical(top: Radius.circular(16)),
                ),
                Positioned(
                  right: 8,
                  top: 8,
                  child: GestureDetector(
                    onTap: onFav,
                    child: Container(
                      padding: const EdgeInsets.all(6),
                      decoration: const BoxDecoration(
                          color: Colors.white, shape: BoxShape.circle),
                      child: Icon(
                        isFav ? Icons.favorite : Icons.favorite_border,
                        size: 18,
                        color: isFav ? AppColors.red : AppColors.textGrey,
                      ),
                    ),
                  ),
                ),
              ],
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(item.name,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                          fontWeight: FontWeight.w700, fontSize: 15)),
                  const SizedBox(height: 4),
                  Row(children: [
                    const Icon(Icons.star, size: 15, color: AppColors.star),
                    const SizedBox(width: 3),
                    Text('${item.rating}',
                        style: const TextStyle(
                            fontSize: 12.5, fontWeight: FontWeight.w600)),
                    Text('  (${item.reviews})',
                        style: const TextStyle(
                            fontSize: 12, color: AppColors.textGrey)),
                  ]),
                  const SizedBox(height: 6),
                  Row(
                    children: [
                      Text('Rs ${item.price}',
                          style: const TextStyle(
                              fontWeight: FontWeight.w800, fontSize: 15.5)),
                      const Spacer(),
                      GestureDetector(
                        onTap: () {
                          context.read<CartProvider>().add(item,
                              size: item.sizes.isNotEmpty
                                  ? item.sizes.first
                                  : null);
                          ScaffoldMessenger.of(context)
                              .showSnackBar(SnackBar(
                            content: Text('${item.name} added to cart'),
                            duration: const Duration(milliseconds: 900),
                          ));
                        },
                        child: Container(
                          width: 30,
                          height: 30,
                          decoration: const BoxDecoration(
                              color: AppColors.yellow,
                              shape: BoxShape.circle),
                          child: const Icon(Icons.add,
                              size: 19, color: AppColors.textDark),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
