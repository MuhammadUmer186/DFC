import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../theme/app_theme.dart';
import 'main_shell.dart';

class TrackOrderScreen extends StatelessWidget {
  final int orderTotal;
  final int itemCount;
  const TrackOrderScreen(
      {super.key, this.orderTotal = 1000, this.itemCount = 2});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      body: Column(
        children: [
          // ── Dark header ──
          Container(
            color: AppColors.navy,
            padding: const EdgeInsets.fromLTRB(14, 0, 14, 14),
            child: SafeArea(
              bottom: false,
              child: Row(
                children: [
                  IconButton(
                    icon: const Icon(Icons.arrow_back, color: Colors.white),
                    onPressed: () => Navigator.of(context).pushAndRemoveUntil(
                        MaterialPageRoute(
                            builder: (_) => const MainShell(initialIndex: 2)),
                        (_) => false),
                  ),
                  Expanded(
                    child: Column(children: [
                      Text('Track Order',
                          style: GoogleFonts.inter(
                              color: Colors.white,
                              fontSize: 18,
                              fontWeight: FontWeight.w800)),
                      const Text('#DFC-1048',
                          style: TextStyle(
                              color: AppColors.yellow,
                              fontSize: 13,
                              fontWeight: FontWeight.w700)),
                    ]),
                  ),
                  const Icon(Icons.headset_mic_outlined, color: Colors.white),
                  const SizedBox(width: 8),
                ],
              ),
            ),
          ),
          // ── Map placeholder with painted route ──
          Expanded(
            flex: 5,
            child: Container(
              color: const Color(0xFFEDEDE8),
              child: CustomPaint(
                painter: _RoutePainter(),
                child: Stack(children: const [
                  Positioned(
                      left: 60, top: 40,
                      child: _MapPin(icon: Icons.storefront)),
                  Positioned(
                      right: 90, bottom: 50,
                      child: _MapPin(icon: Icons.sports_motorsports)),
                ]),
              ),
            ),
          ),
          // ── Status sheet ──
          Container(
            width: double.infinity,
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.vertical(top: Radius.circular(26)),
            ),
            child: SafeArea(
              top: false,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 20, 20, 12),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    RichText(
                      text: TextSpan(
                        style: GoogleFonts.inter(
                            fontSize: 22,
                            fontWeight: FontWeight.w800,
                            color: AppColors.textDark),
                        children: const [
                          TextSpan(text: 'Arriving in '),
                          TextSpan(
                              text: '12 min',
                              style: TextStyle(color: AppColors.orange)),
                        ],
                      ),
                    ),
                    const SizedBox(height: 18),
                    const _StatusStepper(currentStep: 2),
                    const SizedBox(height: 18),
                    // Rider card
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: AppColors.border),
                      ),
                      child: Row(children: [
                        const CircleAvatar(
                            radius: 24,
                            backgroundColor: Color(0xFFEFE6D2),
                            child: Text('🧑‍✈️', style: TextStyle(fontSize: 22))),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Row(children: const [
                            Text('Ali',
                                style: TextStyle(
                                    fontWeight: FontWeight.w800,
                                    fontSize: 16)),
                            Text('  •  Your rider',
                                style: TextStyle(
                                    color: AppColors.textGrey, fontSize: 13)),
                          ]),
                        ),
                        _RoundAction(icon: Icons.call),
                        const SizedBox(width: 10),
                        _RoundAction(icon: Icons.chat_bubble_outline),
                      ]),
                    ),
                    const SizedBox(height: 12),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 14, vertical: 14),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: AppColors.border),
                      ),
                      child: Row(children: [
                        const Icon(Icons.shopping_bag_outlined, size: 20),
                        const SizedBox(width: 10),
                        Text('$itemCount items  •  Rs $orderTotal',
                            style: const TextStyle(
                                fontWeight: FontWeight.w700, fontSize: 15)),
                        const Spacer(),
                        const Icon(Icons.keyboard_arrow_down,
                            color: AppColors.textGrey),
                      ]),
                    ),
                    const SizedBox(height: 12),
                    SizedBox(
                      width: double.infinity,
                      height: 52,
                      child: OutlinedButton(
                        onPressed: () {},
                        style: OutlinedButton.styleFrom(
                          side: const BorderSide(
                              color: AppColors.yellow, width: 1.6),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(14)),
                        ),
                        child: Text('View order',
                            style: GoogleFonts.inter(
                                color: AppColors.yellowDark,
                                fontSize: 16,
                                fontWeight: FontWeight.w700)),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _MapPin extends StatelessWidget {
  final IconData icon;
  const _MapPin({required this.icon});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: AppColors.navy,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.yellow, width: 2),
      ),
      child: Icon(icon, color: AppColors.yellow, size: 22),
    );
  }
}

class _RoutePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final grid = Paint()
      ..color = Colors.white
      ..strokeWidth = 6;
    for (double x = 30; x < size.width; x += 90) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), grid);
    }
    for (double y = 30; y < size.height; y += 80) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    }
    final route = Paint()
      ..color = AppColors.yellow
      ..strokeWidth = 5
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;
    final p = Path()
      ..moveTo(85, 75)
      ..lineTo(85, size.height * 0.4)
      ..lineTo(size.width * 0.55, size.height * 0.4)
      ..lineTo(size.width * 0.55, size.height * 0.75)
      ..lineTo(size.width - 110, size.height * 0.75);
    canvas.drawPath(p, route);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _StatusStepper extends StatelessWidget {
  final int currentStep; // 0..3
  const _StatusStepper({required this.currentStep});

  static const _steps = <(String, IconData)>[
    ('Confirmed', Icons.check),
    ('Preparing', Icons.check),
    ('On the way', Icons.sports_motorsports),
    ('Delivered', Icons.circle),
  ];

  @override
  Widget build(BuildContext context) {
    return Row(
      children: List.generate(_steps.length * 2 - 1, (i) {
        if (i.isOdd) {
          final done = (i ~/ 2) < currentStep;
          return Expanded(
            child: Container(
              height: 3,
              margin: const EdgeInsets.only(bottom: 22),
              color: done ? AppColors.yellow : AppColors.border,
            ),
          );
        }
        final idx = i ~/ 2;
        final done = idx < currentStep;
        final active = idx == currentStep;
        return Column(children: [
          Container(
            width: 34, height: 34,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: done || active ? AppColors.yellow : AppColors.border,
            ),
            child: Icon(
              done ? Icons.check : _steps[idx].$2,
              size: 18,
              color: done || active ? AppColors.textDark : Colors.white,
            ),
          ),
          const SizedBox(height: 6),
          Text(_steps[idx].$1,
              style: TextStyle(
                  fontSize: 10.5,
                  fontWeight: active ? FontWeight.w800 : FontWeight.w600,
                  color: done || active
                      ? AppColors.textDark
                      : AppColors.textGrey)),
        ]);
      }),
    );
  }
}

class _RoundAction extends StatelessWidget {
  final IconData icon;
  const _RoundAction({required this.icon});
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 42, height: 42,
      decoration: const BoxDecoration(
          color: AppColors.yellow, shape: BoxShape.circle),
      child: Icon(icon, size: 20, color: AppColors.textDark),
    );
  }
}
