import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import '../providers/cart_provider.dart';
import '../theme/app_theme.dart';
import 'track_order_screen.dart';

class CheckoutScreen extends StatefulWidget {
  const CheckoutScreen({super.key});
  @override
  State<CheckoutScreen> createState() => _CheckoutScreenState();
}

class _CheckoutScreenState extends State<CheckoutScreen> {
  int _mode = 0; // 0 delivery, 1 pickup
  int _payment = 0;
  String _time = 'As soon as possible  •  25–35 min';

  static const _payments = <(IconData?, String, String?)>[
    (Icons.payments_outlined, 'Cash on Delivery', null),
    (null, 'JazzCash', '🟥'),
    (null, 'Easypaisa', '🟩'),
    (Icons.credit_card, 'Debit / Credit Card', null),
  ];

  @override
  Widget build(BuildContext context) {
    final cart = context.watch<CartProvider>();
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        leading: IconButton(
            icon: const Icon(Icons.arrow_back),
            onPressed: () => Navigator.pop(context)),
        title: Text('Checkout',
            style: GoogleFonts.inter(fontSize: 19, fontWeight: FontWeight.w800)),
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView(
              padding: const EdgeInsets.fromLTRB(18, 6, 18, 12),
              children: [
                // Delivery / Pickup toggle
                Container(
                  padding: const EdgeInsets.all(5),
                  decoration: BoxDecoration(
                    color: const Color(0xFFF2F2F0),
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Row(
                    children: List.generate(2, (i) {
                      final sel = _mode == i;
                      return Expanded(
                        child: GestureDetector(
                          onTap: () => setState(() => _mode = i),
                          child: Container(
                            padding: const EdgeInsets.symmetric(vertical: 11),
                            decoration: BoxDecoration(
                              color: sel ? AppColors.yellow : Colors.transparent,
                              borderRadius: BorderRadius.circular(11),
                            ),
                            alignment: Alignment.center,
                            child: Text(i == 0 ? 'Delivery' : 'Pickup',
                                style: TextStyle(
                                    fontWeight: FontWeight.w700,
                                    color: sel
                                        ? AppColors.textDark
                                        : AppColors.textGrey)),
                          ),
                        ),
                      );
                    }),
                  ),
                ),
                const SizedBox(height: 18),
                _title('Delivery Address'),
                const SizedBox(height: 10),
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: const Color(0xFFFFFBF0),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: AppColors.yellow),
                  ),
                  child: Row(children: [
                    Container(
                      width: 42, height: 42,
                      decoration: const BoxDecoration(
                          color: AppColors.yellow, shape: BoxShape.circle),
                      child: const Icon(Icons.home,
                          color: Colors.white, size: 22),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: const [
                          Text('Home',
                              style: TextStyle(
                                  fontWeight: FontWeight.w800, fontSize: 15.5)),
                          Text('Wah Cantt, Pakistan',
                              style: TextStyle(
                                  color: AppColors.textGrey, fontSize: 13)),
                        ],
                      ),
                    ),
                    const Text('Change',
                        style: TextStyle(
                            color: AppColors.orange,
                            fontWeight: FontWeight.w700)),
                  ]),
                ),
                const SizedBox(height: 18),
                _title('Delivery Time'),
                const SizedBox(height: 10),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: AppColors.border),
                  ),
                  child: Row(children: [
                    const Icon(Icons.access_time,
                        color: AppColors.textGrey, size: 20),
                    const SizedBox(width: 10),
                    Expanded(
                        child: Text(_time,
                            style: const TextStyle(
                                fontWeight: FontWeight.w600, fontSize: 14.5))),
                    const Icon(Icons.keyboard_arrow_down,
                        color: AppColors.textGrey),
                  ]),
                ),
                const SizedBox(height: 18),
                _title('Payment Method'),
                const SizedBox(height: 10),
                Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: AppColors.border),
                  ),
                  child: Column(
                    children: List.generate(_payments.length, (i) {
                      final (icon, name, emoji) = _payments[i];
                      return Column(
                        children: [
                          if (i > 0)
                            const Divider(
                                height: 1, color: AppColors.border),
                          RadioListTile<int>(
                            value: i,
                            groupValue: _payment,
                            onChanged: (v) =>
                                setState(() => _payment = v!),
                            activeColor: AppColors.yellowDark,
                            controlAffinity:
                                ListTileControlAffinity.trailing,
                            title: Row(children: [
                              if (icon != null)
                                Icon(icon,
                                    size: 22, color: AppColors.textDark)
                              else
                                Text(emoji ?? '',
                                    style:
                                        const TextStyle(fontSize: 18)),
                              const SizedBox(width: 12),
                              Text(name,
                                  style: const TextStyle(
                                      fontSize: 15,
                                      fontWeight: FontWeight.w600)),
                            ]),
                          ),
                        ],
                      );
                    }),
                  ),
                ),
                const SizedBox(height: 20),
                Row(children: [
                  Text('Order Total',
                      style: GoogleFonts.inter(
                          fontSize: 17, fontWeight: FontWeight.w800)),
                  const Spacer(),
                  Text('Rs ${cart.total}',
                      style: GoogleFonts.inter(
                          fontSize: 22,
                          fontWeight: FontWeight.w800,
                          color: AppColors.orange)),
                ]),
              ],
            ),
          ),
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(18, 6, 18, 12),
              child: ElevatedButton(
                onPressed: cart.lines.isEmpty
                    ? null
                    : () {
                        final total = cart.total;
                        final count = cart.itemCount;
                        cart.clear();
                        Navigator.of(context).pushReplacement(
                          MaterialPageRoute(
                            builder: (_) => TrackOrderScreen(
                                orderTotal: total, itemCount: count),
                          ),
                        );
                      },
                child: const Text('Place Order'),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _title(String t) => Text(t,
      style: GoogleFonts.inter(fontSize: 16.5, fontWeight: FontWeight.w800));
}
