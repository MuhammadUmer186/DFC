import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import '../services/auth_service.dart';
import '../theme/app_theme.dart';
import '../widgets/dfc_logo.dart';
import 'main_shell.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _phoneCtrl = TextEditingController();
  bool _loading = false;

  Future<void> _googleSignIn() async {
    setState(() => _loading = true);
    try {
      final user = await AuthService.instance.signInWithGoogle();
      if (user != null && mounted) _goHome();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('Google sign-in failed: $e'),
          backgroundColor: AppColors.red,
        ));
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  void _goHome() {
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const MainShell()),
      (_) => false,
    );
  }

  @override
  void dispose() {
    _phoneCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.navy,
      body: Column(
        children: [
          // ── Hero header with food image / logo ──
          Expanded(
            flex: 5,
            child: Stack(
              fit: StackFit.expand,
              children: [
                Image.asset(
                  'assets/images/login_hero.png',
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => Container(
                    decoration: const BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [Color(0xFF1A1408), AppColors.navy],
                      ),
                    ),
                    alignment: Alignment.bottomCenter,
                    child: const Padding(
                      padding: EdgeInsets.only(bottom: 110),
                      child: Text('🍔  🍟  🥤', style: TextStyle(fontSize: 44)),
                    ),
                  ),
                ),
                Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        Colors.black.withOpacity(0.15),
                        Colors.black.withOpacity(0.55),
                      ],
                    ),
                  ),
                ),
                SafeArea(
                  child: Column(
                    children: [
                      const SizedBox(height: 24),
                      const DfcLogo(size: 110),
                      const Spacer(),
                      Text('Data Finger Chips',
                          style: GoogleFonts.inter(
                              color: Colors.white,
                              fontSize: 30,
                              fontWeight: FontWeight.w800)),
                      const SizedBox(height: 6),
                      RichText(
                        text: TextSpan(
                          style: GoogleFonts.inter(
                              fontSize: 17, fontWeight: FontWeight.w700),
                          children: const [
                            TextSpan(text: 'Crispy. ',
                                style: TextStyle(color: AppColors.orange)),
                            TextSpan(text: 'Fresh. ',
                                style: TextStyle(color: AppColors.yellow)),
                            TextSpan(text: 'Delivered.',
                                style: TextStyle(color: Colors.white)),
                          ],
                        ),
                      ),
                      const SizedBox(height: 22),
                    ],
                  ),
                ),
              ],
            ),
          ),
          // ── White sheet ──
          Expanded(
            flex: 6,
            child: Container(
              width: double.infinity,
              decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
              ),
              child: SafeArea(
                top: false,
                child: SingleChildScrollView(
                  padding: const EdgeInsets.fromLTRB(22, 26, 22, 12),
                  child: Column(
                    children: [
                      Text('Welcome to DFC',
                          style: GoogleFonts.inter(
                              fontSize: 30, fontWeight: FontWeight.w800)),
                      const SizedBox(height: 8),
                      const Text(
                        'Sign in to order, track deliveries and earn rewards.',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: AppColors.textGrey, fontSize: 15),
                      ),
                      const SizedBox(height: 24),
                      // Google button
                      SizedBox(
                        height: 56,
                        width: double.infinity,
                        child: OutlinedButton(
                          onPressed: _loading ? null : _googleSignIn,
                          style: OutlinedButton.styleFrom(
                            side: const BorderSide(color: AppColors.textDark, width: 1.2),
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(16)),
                          ),
                          child: _loading
                              ? const SizedBox(
                                  width: 22, height: 22,
                                  child: CircularProgressIndicator(strokeWidth: 2.4))
                              : Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    const _GoogleG(),
                                    const SizedBox(width: 12),
                                    Text('Continue with Google',
                                        style: GoogleFonts.inter(
                                            color: AppColors.textDark,
                                            fontSize: 17,
                                            fontWeight: FontWeight.w600)),
                                  ],
                                ),
                        ),
                      ),
                      const SizedBox(height: 20),
                      Row(children: const [
                        Expanded(child: Divider(color: AppColors.border)),
                        Padding(
                          padding: EdgeInsets.symmetric(horizontal: 12),
                          child: Text('or continue with',
                              style: TextStyle(color: AppColors.textGrey)),
                        ),
                        Expanded(child: Divider(color: AppColors.border)),
                      ]),
                      const SizedBox(height: 20),
                      // Phone field with PK flag + code
                      TextField(
                        controller: _phoneCtrl,
                        keyboardType: TextInputType.phone,
                        inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                        decoration: InputDecoration(
                          hintText: 'Mobile number',
                          prefixIcon: Padding(
                            padding: const EdgeInsets.only(left: 14, right: 10),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: const [
                                Text('🇵🇰', style: TextStyle(fontSize: 22)),
                                Icon(Icons.arrow_drop_down,
                                    color: AppColors.textGrey),
                                SizedBox(width: 4),
                                Text('+92',
                                    style: TextStyle(
                                        fontSize: 16,
                                        fontWeight: FontWeight.w600)),
                                SizedBox(width: 10),
                                SizedBox(
                                    height: 26,
                                    child: VerticalDivider(
                                        color: AppColors.border, width: 1)),
                              ],
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 18),
                      ElevatedButton(
                        onPressed: () {
                          if (_phoneCtrl.text.trim().length < 10) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                  content: Text('Enter a valid mobile number')),
                            );
                            return;
                          }
                          _goHome(); // Phone OTP flow can be added later.
                        },
                        child: const Text('Continue'),
                      ),
                      const SizedBox(height: 14),
                      TextButton(
                        onPressed: _goHome,
                        child: Text('Continue as Guest',
                            style: GoogleFonts.inter(
                                color: AppColors.orange,
                                fontSize: 17,
                                fontWeight: FontWeight.w600)),
                      ),
                      const SizedBox(height: 6),
                      RichText(
                        textAlign: TextAlign.center,
                        text: const TextSpan(
                          style: TextStyle(
                              color: AppColors.textGrey, fontSize: 13.5),
                          children: [
                            TextSpan(text: 'By continuing, you agree to our '),
                            TextSpan(text: 'Terms',
                                style: TextStyle(color: AppColors.orange)),
                            TextSpan(text: ' & '),
                            TextSpan(text: 'Privacy Policy',
                                style: TextStyle(color: AppColors.orange)),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// Multicolour Google "G".
class _GoogleG extends StatelessWidget {
  const _GoogleG();
  @override
  Widget build(BuildContext context) {
    return Image.asset(
      'assets/images/google_logo.png',
      width: 26,
      height: 26,
      errorBuilder: (_, __, ___) => ShaderMask(
        shaderCallback: (r) => const LinearGradient(colors: [
          Color(0xFF4285F4), Color(0xFFEA4335),
          Color(0xFFFBBC05), Color(0xFF34A853),
        ]).createShader(r),
        child: Text('G',
            style: GoogleFonts.inter(
                fontSize: 24, fontWeight: FontWeight.w800, color: Colors.white)),
      ),
    );
  }
}
