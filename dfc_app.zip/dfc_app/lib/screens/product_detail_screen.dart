import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import '../models/food_item.dart';
import '../providers/cart_provider.dart';
import '../theme/app_theme.dart';
import '../widgets/dfc_logo.dart';

class ProductDetailScreen extends StatefulWidget {
  final FoodItem item;
  const ProductDetailScreen({super.key, required this.item});

  @override
  State<ProductDetailScreen> createState() => _ProductDetailScreenState();
}

class _ProductDetailScreenState extends State<ProductDetailScreen> {
  late SizeOption? _size =
      widget.item.sizes.isNotEmpty ? widget.item.sizes.last : null;
  final Set<AddOn> _addOns = {};
  int _qty = 1;
  bool _fav = false;

  int get _total =>
      (((_size?.price ?? widget.item.price) +
              _addOns.fold(0, (s, a) => s + a.price)) *
          _qty);

  @override
  Widget build(BuildContext context) {
    final item = widget.item;
    return Scaffold(
      backgroundColor: Colors.white,
      body: Column(
        children: [
          // ── Hero image ──
          Stack(
            children: [
              FoodImage(
                asset: item.asset,
                emoji: item.emoji,
                width: double.infinity,
                height: 320,
                radius: BorderRadius.zero,
              ),
              Positioned(
                top: 0, left: 0, right: 0,
                child: SafeArea(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                    child: Row(
                      children: [
                        _RoundBtn(
                          icon: Icons.arrow_back,
                          onTap: () => Navigator.pop(context),
                        ),
                        const Spacer(),
                        _RoundBtn(
                          icon: _fav ? Icons.favorite : Icons.favorite_border,
                          color: _fav ? AppColors.red : AppColors.textDark,
                          onTap: () => setState(() => _fav = !_fav),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              Positioned(
                bottom: 10, left: 0, right: 0,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: List.generate(
                    4,
                    (i) => Container(
                      width: 7, height: 7,
                      margin: const EdgeInsets.symmetric(horizontal: 3),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: i == 0 ? AppColors.yellow : Colors.white70,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
          // ── Details sheet ──
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(20, 18, 20, 10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: Text(item.name,
                            style: GoogleFonts.inter(
                                fontSize: 26, fontWeight: FontWeight.w800)),
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Row(children: [
                            const Icon(Icons.star,
                                size: 18, color: AppColors.star),
                            Text(' ${item.rating}',
                                style: const TextStyle(
                                    fontSize: 17,
                                    fontWeight: FontWeight.w800)),
                          ]),
                          Text('(${item.reviews} reviews)',
                              style: const TextStyle(
                                  fontSize: 12, color: AppColors.textGrey)),
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  Text(item.description,
                      style: const TextStyle(
                          color: AppColors.textGrey, fontSize: 14.5)),
                  if (item.sizes.isNotEmpty) ...[
                    const SizedBox(height: 20),
                    const _SectionTitle('Choose Size'),
                    const SizedBox(height: 10),
                    Row(
                      children: item.sizes
                          .map((s) => Expanded(
                                child: Padding(
                                  padding: EdgeInsets.only(
                                      right: s == item.sizes.last ? 0 : 12),
                                  child: _SizeCard(
                                    size: s,
                                    selected: _size == s,
                                    onTap: () => setState(() => _size = s),
                                  ),
                                ),
                              ))
                          .toList(),
                    ),
                  ],
                  if (item.addOns.isNotEmpty) ...[
                    const SizedBox(height: 20),
                    const _SectionTitle('Add-ons'),
                    const SizedBox(height: 6),
                    ...item.addOns.map((a) => _AddOnRow(
                          addOn: a,
                          checked: _addOns.contains(a),
                          onChanged: (v) => setState(() =>
                              v! ? _addOns.add(a) : _addOns.remove(a)),
                        )),
                  ],
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      const _SectionTitle('Quantity'),
                      const Spacer(),
                      _QtyStepper(
                        qty: _qty,
                        onChanged: (q) => setState(() => _qty = q),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                ],
              ),
            ),
          ),
          // ── Add to cart bar ──
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(20, 6, 20, 12),
              child: ElevatedButton(
                onPressed: () {
                  context.read<CartProvider>().add(item,
                      size: _size, addOns: _addOns.toList(), qty: _qty);
                  Navigator.pop(context);
                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                    content: Text('${item.name} added to cart'),
                    duration: const Duration(milliseconds: 1000),
                  ));
                },
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(Icons.shopping_cart, size: 20),
                    const SizedBox(width: 10),
                    Text('Add to Cart  •  Rs $_total'),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _RoundBtn extends StatelessWidget {
  final IconData icon;
  final Color color;
  final VoidCallback onTap;
  const _RoundBtn(
      {required this.icon, required this.onTap, this.color = AppColors.textDark});
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 42, height: 42,
        decoration: const BoxDecoration(
            color: Colors.white, shape: BoxShape.circle),
        child: Icon(icon, color: color, size: 22),
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String text;
  const _SectionTitle(this.text);
  @override
  Widget build(BuildContext context) => Text(text,
      style: GoogleFonts.inter(fontSize: 16.5, fontWeight: FontWeight.w800));
}

class _SizeCard extends StatelessWidget {
  final SizeOption size;
  final bool selected;
  final VoidCallback onTap;
  const _SizeCard(
      {required this.size, required this.selected, required this.onTap});
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: selected ? const Color(0xFFFFF8E6) : Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
              color: selected ? AppColors.yellow : AppColors.border,
              width: selected ? 2 : 1),
        ),
        child: Column(
          children: [
            Text(size.label,
                style: const TextStyle(
                    fontWeight: FontWeight.w700, fontSize: 15)),
            const SizedBox(height: 2),
            Text('Rs ${size.price}',
                style: TextStyle(
                    color: selected
                        ? AppColors.yellowDark
                        : AppColors.textGrey,
                    fontWeight: FontWeight.w700,
                    fontSize: 13.5)),
          ],
        ),
      ),
    );
  }
}

class _AddOnRow extends StatelessWidget {
  final AddOn addOn;
  final bool checked;
  final ValueChanged<bool?> onChanged;
  const _AddOnRow(
      {required this.addOn, required this.checked, required this.onChanged});
  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        SizedBox(
          width: 34,
          child: Checkbox(
            value: checked,
            onChanged: onChanged,
            activeColor: AppColors.yellow,
            checkColor: AppColors.textDark,
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
          ),
        ),
        const SizedBox(width: 4),
        Expanded(
            child: Text(addOn.name,
                style: const TextStyle(
                    fontSize: 15, fontWeight: FontWeight.w600))),
        Text('Rs ${addOn.price}',
            style: const TextStyle(
                fontSize: 14, color: AppColors.textGrey,
                fontWeight: FontWeight.w600)),
      ],
    );
  }
}

class _QtyStepper extends StatelessWidget {
  final int qty;
  final ValueChanged<int> onChanged;
  const _QtyStepper({required this.qty, required this.onChanged});
  @override
  Widget build(BuildContext context) {
    Widget btn(IconData i, VoidCallback onTap, {bool primary = false}) =>
        GestureDetector(
          onTap: onTap,
          child: Container(
            width: 34, height: 34,
            decoration: BoxDecoration(
              color: primary ? AppColors.yellow : Colors.white,
              shape: BoxShape.circle,
              border: primary ? null : Border.all(color: AppColors.border),
            ),
            child: Icon(i, size: 18, color: AppColors.textDark),
          ),
        );
    return Row(children: [
      btn(Icons.remove, () => onChanged(qty > 1 ? qty - 1 : 1)),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Text('$qty',
            style:
                const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
      ),
      btn(Icons.add, () => onChanged(qty + 1), primary: true),
    ]);
  }
}
