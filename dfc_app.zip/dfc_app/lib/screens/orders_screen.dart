import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../theme/app_theme.dart';
import 'track_order_screen.dart';

class OrdersScreen extends StatelessWidget {
  const OrdersScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 14),
              child: Text('My Orders',
                  style: GoogleFonts.inter(
                      fontSize: 20, fontWeight: FontWeight.w800)),
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(18, 0, 18, 16),
                children: [
                  OrderTile(
                    id: '#DFC-1048',
                    status: 'On the way',
                    statusColor: AppColors.orange,
                    items: 'Loaded Fries, Zinger Burger',
                    price: 'Rs 1,000',
                    emoji: '🍟',
                    trailing: TextButton(
                      onPressed: () => Navigator.of(context).push(
                          MaterialPageRoute(
                              builder: (_) => const TrackOrderScreen())),
                      child: const Text('Track',
                          style: TextStyle(
                              color: AppColors.orange,
                              fontWeight: FontWeight.w700)),
                    ),
                  ),
                  OrderTile(
                    id: '#DFC-1021',
                    status: 'Delivered',
                    statusColor: AppColors.green,
                    items: 'Chicken Shawarma, Fries',
                    price: 'Rs 750',
                    emoji: '🌯',
                    trailing: OutlinedButton(
                      onPressed: () {},
                      style: OutlinedButton.styleFrom(
                        side: const BorderSide(color: AppColors.yellow),
                        padding:
                            const EdgeInsets.symmetric(horizontal: 16),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10)),
                      ),
                      child: const Text('Reorder',
                          style: TextStyle(
                              color: AppColors.yellowDark,
                              fontWeight: FontWeight.w700)),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class OrderTile extends StatelessWidget {
  final String id, status, items, price, emoji;
  final Color statusColor;
  final Widget trailing;
  const OrderTile({
    super.key,
    required this.id,
    required this.status,
    required this.statusColor,
    required this.items,
    required this.price,
    required this.emoji,
    required this.trailing,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(children: [
        Container(
          width: 62, height: 62,
          decoration: BoxDecoration(
              color: const Color(0xFFF6F0E2),
              borderRadius: BorderRadius.circular(12)),
          alignment: Alignment.center,
          child: Text(emoji, style: const TextStyle(fontSize: 28)),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(children: [
                Text('Order $id',
                    style: const TextStyle(
                        fontWeight: FontWeight.w800, fontSize: 14.5)),
                const Spacer(),
                Text(status,
                    style: TextStyle(
                        color: statusColor,
                        fontSize: 12,
                        fontWeight: FontWeight.w700)),
              ]),
              const SizedBox(height: 3),
              Text(items,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                      color: AppColors.textGrey, fontSize: 13)),
              const SizedBox(height: 4),
              Row(children: [
                Text(price,
                    style: const TextStyle(
                        color: AppColors.orange,
                        fontWeight: FontWeight.w800,
                        fontSize: 15)),
                const Spacer(),
                trailing,
              ]),
            ],
          ),
        ),
      ]),
    );
  }
}
