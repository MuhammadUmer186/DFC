import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../theme/app_theme.dart';

/// Circular DFC logo (yellow ring, fries icon, DFC text).
/// Uses assets/images/logo.png automatically if you add one.
class DfcLogo extends StatelessWidget {
  final double size;
  final bool onDark;
  const DfcLogo({super.key, this.size = 96, this.onDark = true});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: onDark ? Colors.black : Colors.white,
        border: Border.all(color: AppColors.yellow, width: size * 0.045),
      ),
      child: ClipOval(
        child: Image.asset(
          'assets/images/logo.png',
          fit: BoxFit.cover,
          errorBuilder: (_, __, ___) => Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text('🍟', style: TextStyle(fontSize: size * 0.26)),
              Text(
                'DFC',
                style: GoogleFonts.playfairDisplay(
                  color: AppColors.yellow,
                  fontSize: size * 0.28,
                  fontWeight: FontWeight.w800,
                  height: 1,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Product image with graceful emoji fallback until you add real assets.
class FoodImage extends StatelessWidget {
  final String asset;
  final String emoji;
  final double? width, height;
  final BoxFit fit;
  final BorderRadius? radius;
  const FoodImage({
    super.key,
    required this.asset,
    required this.emoji,
    this.width,
    this.height,
    this.fit = BoxFit.cover,
    this.radius,
  });

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: radius ?? BorderRadius.circular(14),
      child: Image.asset(
        asset,
        width: width,
        height: height,
        fit: fit,
        errorBuilder: (_, __, ___) => Container(
          width: width,
          height: height,
          color: const Color(0xFFF1EDE4),
          alignment: Alignment.center,
          child: Text(emoji, style: TextStyle(fontSize: (height ?? 80) * 0.4)),
        ),
      ),
    );
  }
}
