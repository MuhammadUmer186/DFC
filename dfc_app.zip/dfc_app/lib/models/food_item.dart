class SizeOption {
  final String label;
  final int price;
  const SizeOption(this.label, this.price);
}

class AddOn {
  final String name;
  final int price;
  const AddOn(this.name, this.price);
}

class FoodItem {
  final String id;
  final String name;
  final String category;
  final String description;
  final int price;
  final double rating;
  final int reviews;
  final String asset;
  final String emoji;
  final List<SizeOption> sizes;
  final List<AddOn> addOns;

  const FoodItem({
    required this.id,
    required this.name,
    required this.category,
    required this.description,
    required this.price,
    required this.rating,
    required this.reviews,
    required this.asset,
    required this.emoji,
    this.sizes = const [],
    this.addOns = const [],
  });
}

class CartLine {
  final FoodItem item;
  final SizeOption? size;
  final List<AddOn> addOns;
  int quantity;

  CartLine({required this.item, this.size, this.addOns = const [], this.quantity = 1});

  int get unitPrice =>
      (size?.price ?? item.price) + addOns.fold(0, (s, a) => s + a.price);
  int get total => unitPrice * quantity;
}
