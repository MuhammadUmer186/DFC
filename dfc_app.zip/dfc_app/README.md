# 🍟 DFC — Data Finger Chips (Flutter App)

**Crispy. Fresh. Delivered.**

Complete Flutter frontend matching the DFC mockups + Google login backend (Firebase Auth).

## Screens included
| Screen | File |
|---|---|
| Splash (dark navy, logo, tagline) | `lib/screens/splash_screen.dart` |
| Login (Google + PK phone + Guest) | `lib/screens/login_screen.dart` |
| Home (greeting, Wah Cantt, Crunch Deal Rs 899, categories, popular) | `lib/screens/home_screen.dart` |
| Explore Menu (search, chips, grid, favourites) | `lib/screens/menu_screen.dart` |
| Product Detail (sizes, add-ons, quantity, Add to Cart) | `lib/screens/product_detail_screen.dart` |
| Cart (qty steppers, extras, promo `DFC100`, totals) | `lib/screens/cart_screen.dart` |
| Checkout (Delivery/Pickup, address, COD/JazzCash/Easypaisa/Card) | `lib/screens/checkout_screen.dart` |
| Track Order (#DFC-1048, map route, status stepper, rider Ali) | `lib/screens/track_order_screen.dart` |
| Orders + Profile (DFC Rewards 320 pts, recent orders, sign out) | `lib/screens/orders_screen.dart`, `profile_screen.dart` |

## 1. Run it

```bash
flutter create . --platforms=android,ios   # generates android/ ios/ around this code
flutter pub get
flutter run
```

> The app runs immediately in **Guest mode** even before Firebase is configured.

## 2. Google Login setup (the only backend)

1. Go to https://console.firebase.google.com → **Add project** → name it `dfc-app`.
2. Add an **Android app**:
   - Package name: use the `applicationId` from `android/app/build.gradle` (e.g. `com.example.dfc_app` — change it to `com.dfc.app` if you like).
   - Add your **SHA-1** (required for Google Sign-In):
     ```bash
     cd android && ./gradlew signingReport
     ```
     Copy the `SHA1` from the `debug` variant into Firebase project settings.
3. Download **google-services.json** → put it in `android/app/`.
4. In Firebase Console → **Authentication → Sign-in method → Google → Enable**.
5. Edit Gradle files:
   - `android/settings.gradle` (plugins block):
     ```gradle
     id "com.google.gms.google-services" version "4.4.2" apply false
     ```
   - `android/app/build.gradle` (plugins block):
     ```gradle
     id "com.google.gms.google-services"
     ```
   - In the same file set `minSdkVersion 23` and `multiDexEnabled true`.
6. `flutter run` — the **Continue with Google** button now signs users in; the profile screen shows their Google name & photo.

### iOS (optional)
Add an iOS app in Firebase, download `GoogleService-Info.plist` into `ios/Runner/`, and add the `REVERSED_CLIENT_ID` as a URL scheme in `Info.plist`.

## 3. Replace placeholder images

Drop your real photos into `assets/images/` with these names (emoji fallbacks are used until then):

```
logo.png  login_hero.png  google_logo.png
classic_fries.png  loaded_fries.png  zinger_burger.png
chicken_shawarma.png  pizza.png  drink.png
```

## 4. Where things live
- Brand colors/theme → `lib/theme/app_theme.dart`
- Menu items & prices (Rs) → `lib/data/menu_data.dart`
- Cart logic → `lib/providers/cart_provider.dart`
- Google auth → `lib/services/auth_service.dart`
