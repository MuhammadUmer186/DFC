import { Component, effect, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EmployeeService } from '../../../Services/employee';


@Component({
  selector: 'app-employee-list',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './employee-list.html',
  styleUrls: ['./employee-list.css']
})
export class EmployeeListComponent {
  employee=signal<any[]>([]);
  constructor(public service: EmployeeService) {
    this.load();
  }

  load() {
    console.log('Loading employees...');
    return this.service.loadAll().subscribe(res => {this.employee.set(res); console.log('Employees loaded:', res);});
  }

  delete(id: number) {
    this.service.delete(id).subscribe();
    this.load();
    //this.service.loadAll().subscribe(res => this.employee.set(res));
  }
}
