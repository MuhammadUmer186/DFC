import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { DashboardService } from '../../Services/dashboard.service';
import { OrderService, Order } from '../../Services/order.service';
import { PurchaseOrder, PurchaseOrderService } from '../../Services/purchaseorder.service';
import { KitchenOut, KitchenOutService } from '../../Services/kitchenout.service';

@Component({
  selector: 'app-report',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './report1.html',
  styleUrls: ['./report1.css']
})
export class ReportComponent {

  date = signal('');
  loading = signal(false);

  report = signal<any>(null);

  // ⭐ ORDER HISTORY
  orders = signal<Order[]>([]);
  purchaseOrders = signal<PurchaseOrder[]>([]);
  kitchenOuts = signal<KitchenOut[]>([]);

  totalRecords = signal(0);
  first = signal(0);
  rows = signal(5);

  // ⭐ Expand Rows
  expandedOrderId = signal<number | null>(null);
  expandedKitchenId = signal<number | null>(null);

  constructor(
    private dashboardService: DashboardService,
    private orderService: OrderService,
    private purchaseOrderService: PurchaseOrderService,
    private kitchenOutService: KitchenOutService
  ) {}

  formatDateForApi(date: string): string {
    const [year, month, day] = date.split('-');
    return `${month}-${day}-${year}`;
  }

  // ⭐ MAIN REPORT LOAD
  loadReport() {
    if (!this.date()) { alert("Please select date"); return; }
    this.loading.set(true);

    const formattedDate = this.formatDateForApi(this.date());

    this.dashboardService.getDailyReport(formattedDate).subscribe({
      next: (res) => {
        this.report.set(res);
        this.loadOrders(0, this.rows());
        this.loadPurchaseOrders();
        this.loadKitchenOuts();
        this.loading.set(false);
      },
      error: () => this.loading.set(false)
    });
  }

  // ⭐ LOAD ORDERS BY DATE
  loadOrders(page: number, pageSize: number) {
    const selectedDate = this.date(); // YYYY-MM-DD
    this.orderService.getPagedOrdersByDate(selectedDate, page, pageSize).subscribe({
      next: (res) => {
        this.orders.set(res.items);
        this.totalRecords.set(res.totalCount);
      }
    });
  }

  // ⭐ LOAD PURCHASE ORDERS
  loadPurchaseOrders() {
    const selectedDate = this.date(); // YYYY-MM-DD
    this.purchaseOrderService.getByDate(selectedDate).subscribe({
      next: (res) => this.purchaseOrders.set(res)
    });
  }

  // ⭐ LOAD KITCHEN OUTS BY DATE
  loadKitchenOuts() {
    const selectedDate = this.date(); // YYYY-MM-DD
    this.kitchenOutService.getPagedByDate(selectedDate, 0, 50).subscribe({ // adjust pageSize as needed
      next: (res) => this.kitchenOuts.set(res.items)
    });
  }

  // ⭐ Expand Purchase Order Items
  toggleDetails(id: number) {
    this.expandedOrderId.set(this.expandedOrderId() === id ? null : id);
  }

  // ⭐ Expand Kitchen Out Items
  toggleKitchenDetails(id: number) {
    this.expandedKitchenId.set(this.expandedKitchenId() === id ? null : id);
  }

  // ⭐ PAGINATOR
  onPageChange(event: any) {
    this.first.set(event.first);
    this.rows.set(event.rows);
    const page = event.first / event.rows;
    this.loadOrders(page, event.rows);
  }

  // ⭐ DELETE ORDER
  deleteOrder(id: number) {
    if (!confirm("Delete this order?")) return;
    this.orderService.DeleteOrderById(id).subscribe(() => {
      this.loadOrders(this.first() / this.rows(), this.rows());
    });
  }

}
